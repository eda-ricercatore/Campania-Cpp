#include <iostream>
#include <string>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <climits>
#include <cfloat>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
#include "Student.h"

main() {
	int a[];
	a[50];
	a[23]=123456789;
	cout << "a is: " << a[23] << endl;
}
